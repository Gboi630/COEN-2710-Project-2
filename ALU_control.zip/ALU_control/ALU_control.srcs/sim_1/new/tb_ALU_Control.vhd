library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ALU_Control_tb is
end ALU_Control_tb;

architecture Behavioral of ALU_Control_tb is

    component ALU_Control
        Port ( 
            Funct7: in  std_logic_vector(6 downto 0);
            Funct3: in  std_logic_vector(2 downto 0);
            ALUOp: in  std_logic_vector(1 downto 0);
            ALUOperation: out std_logic_vector(3 downto 0)
        );
    end component;

    signal Funct7: std_logic_vector(6 downto 0);
    signal Funct3: std_logic_vector(2 downto 0);
    signal ALUOp: std_logic_vector(1 downto 0);
    signal ALUOperation: std_logic_vector(3 downto 0);

begin

    ALU_Control_Test: ALU_Control
        port map (
            Funct7 => Funct7,
            Funct3 => Funct3,
            ALUOp => ALUOp,
            ALUOperation => ALUOperation
        );

    process
    begin

        -- ALUOp = 00 for ADD
        ALUOp  <= "00";
        Funct3 <= "000";
        Funct7 <= "0000000";
        wait for 10 ns;

        -- ALUOp = 01 for SUB
        ALUOp  <= "01";
        Funct3 <= "000";
        Funct7 <= "0000000";
        wait for 10 ns;

        -- R-type ADD
        ALUOp  <= "10";
        Funct3 <= "000";
        Funct7 <= "0000000";
        wait for 10 ns;

        -- R-type SUB
        ALUOp  <= "10";
        Funct3 <= "000";
        Funct7 <= "0100000";
        wait for 10 ns;

        -- AND
        ALUOp  <= "10";
        Funct3 <= "111";
        Funct7 <= "0000000";
        wait for 10 ns;

        -- OR
        ALUOp  <= "10";
        Funct3 <= "110";
        Funct7 <= "0000000";
        wait for 10 ns;

        wait;

    end process;

end Behavioral;