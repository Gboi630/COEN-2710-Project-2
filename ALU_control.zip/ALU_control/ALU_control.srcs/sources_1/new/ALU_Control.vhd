----------------------------------------------------------------------------------
-- Company: 
-- Engineer: Parker Alig
-- 
-- Create Date: 04/07/2026 11:21:54 PM
-- Design Name: 
-- Module Name: ALU_Control - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ALU_Control is
  Port ( 
        Funct7: in std_logic_vector(6 downto 0);
        Funct3: in std_logic_vector(2 downto 0);
        ALUOp: in std_logic_vector(1 downto 0);
        ALUOperation: out std_logic_vector(3 downto 0)
  );
end ALU_Control;

architecture Behavioral of ALU_Control is
begin

process(ALUOp, Funct7, Funct3)
begin
    -- Default
    ALUOperation <= "0000";

    -- Load/Store
    if ALUOp = "00" then
        ALUOperation <= "0010";

    -- Branch
    elsif ALUOp = "01" then
        ALUOperation <= "0110";

    -- R-Type instructions
    elsif ALUOp = "10" then

        -- ADD instruction
        if Funct3 = "000" and Funct7 = "0000000" then
            ALUOperation <= "0010";

        -- SUB instruction
        elsif Funct3 = "000" and Funct7 = "0100000" then
            ALUOperation <= "0110";

        -- AND instruction
        elsif Funct3 = "111" then
            ALUOperation <= "0000";

        -- OR instruction
        elsif Funct3 = "110" then
            ALUOperation <= "0001";

        end if;

    end if;

end process;

end Behavioral;
