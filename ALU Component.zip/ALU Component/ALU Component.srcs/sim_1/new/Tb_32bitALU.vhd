--Giancarlo Ortega and Parker Alig--

-- Testbench for code--


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_ALU_32bit is
end TB_ALU_32bit;

architecture Behavioral of TB_ALU_32bit is

    component ALU_32bit
        Port (
            a            : in  STD_LOGIC_VECTOR(31 downto 0);
            b            : in  STD_LOGIC_VECTOR(31 downto 0);
            ALUOperation : in  STD_LOGIC_VECTOR(3 downto 0);
            CarryOut     : out STD_LOGIC;
            Result       : out STD_LOGIC_VECTOR(31 downto 0);
            Overflow     : out STD_LOGIC;
            Zero         : out STD_LOGIC
        );
    end component;

    signal a            : STD_LOGIC_VECTOR(31 downto 0);
    signal b            : STD_LOGIC_VECTOR(31 downto 0);
    signal ALUOperation : STD_LOGIC_VECTOR(3 downto 0);
    signal CarryOut     : STD_LOGIC;
    signal Result       : STD_LOGIC_VECTOR(31 downto 0);
    signal Overflow     : STD_LOGIC;
    signal Zero         : STD_LOGIC;

begin

    DUT: ALU_32bit
        port map (
            a            => a,
            b            => b,
            ALUOperation => ALUOperation,
            CarryOut     => CarryOut,
            Result       => Result,
            Overflow     => Overflow,
            Zero         => Zero
        );

    stim_proc: process
    begin

        -- Test 1: AND
        a <= "00000000000000000000000000000001";
        b <= "00000000000000000000000000001011";
        ALUOperation <= "0000";
        wait for 20 ns;

        -- Test 2: OR
        a <= "11111111111111110000000000000000";
        b <= "00000000000000001111111111111111";
        ALUOperation <= "0001";
        wait for 20 ns;

        -- Test 3: ADD
        a <= "00000000000000000000000000001000";
        b <= "00000000000000000000000000001000";
        ALUOperation <= "0010";
        wait for 20 ns;

        -- Test 4: SUB
        -- 36 - 4 = 32
        a <= "00000000000000000000000000100100";
        b <= "00000000000000000000000000000100";
        ALUOperation <= "0110";
        wait for 20 ns;

        -- Test 5: SLT
        a <= "00000000000000000110000000000000";
        b <= "01111111111111111001111111111111";
        ALUOperation <= "0111";
        wait for 20 ns;

        -- Test 6: NOR
        a <= "11000111111011100111111111110011";
        b <= "11111000000000000110101111110000";
        ALUOperation <= "1100";
        wait for 20 ns;

        -- Test 7: Zero output
        a <= "00000000000000000000000000100100";
        b <= "00000000000000000000000000100100";
        ALUOperation <= "0110";
        wait for 20 ns;
        
         -- Test 8: ADD with overflow
               a <= "01111111111111111111111111111111"; -- the highest positive
               b <= "00000000000000000000000000000001"; -- adding 1
               ALUOperation <= "0010";
               wait for 20 ns;
              
               -- Test 9: SUB with overflow
               a <= "10000000000000000000000000000000"; -- the smallest number
               b <= "00000000000000000000000000000001"; -- adding 1
               ALUOperation <= "0110";

        wait;
    end process;

end Behavioral;
