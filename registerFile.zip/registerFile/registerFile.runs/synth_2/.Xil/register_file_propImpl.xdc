set_property SRC_FILE_INFO {cfile:{C:/Users/parke/OneDrive/Desktop/COEN 2710 VHDL/registerFile/registerFile/registerFile.srcs/constrs_1/new/register_file_constraint.xdc} rfile:../../../registerFile.srcs/constrs_1/new/register_file_constraint.xdc id:1} [current_design]
set_property src_info {type:XDC file:1 line:42 export:INPUT save:INPUT read:READ} [current_design]
set_max_delay -datapath_only -from [all_inputs] -to [all_outputs] 50.000
