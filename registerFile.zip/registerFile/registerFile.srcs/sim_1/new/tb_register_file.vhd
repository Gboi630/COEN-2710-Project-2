library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity testbench_register_file is
--  Port ( );
end testbench_register_file;

architecture Test_Arch of testbench_register_file is
    component register_file
        Port(
            read_addr1_in : in STD_LOGIC_VECTOR(4 downto 0);
            read_addr2_in : in STD_LOGIC_VECTOR(4 downto 0);
            reset : in STD_LOGIC;
            clk : in STD_LOGIC;
            write_enable_in : in STD_LOGIC;
            write_addr_in : in STD_LOGIC_VECTOR(4 downto 0);
            write_data_in : in STD_LOGIC_VECTOR(31 downto 0);
            read_data1_out : out STD_LOGIC_VECTOR(31 downto 0);
            read_data2_out : out STD_LOGIC_VECTOR(31 downto 0)
        );
        
    end component;
    signal ra1, ra2, wa : STD_LOGIC_VECTOR(4 downto 0);
    signal rd1, rd2, wd : STD_LOGIC_VECTOR(31 downto 0);
    signal clk, rst, we : STD_LOGIC;
  
  for DUT1: register_file use entity WORK.register_file(behavioral_arch);
  --for DUT1: fourbit_adder use entity WORK.FOURBIT_ADDER(MY_BEHAVIORAL1);
  --for DUT1: fourbit_adder use entity WORK.FOURBIT_ADDER(MY_BEHAVIORAL1);
  
  begin
    DUT1: register_file port map (read_data1_out => rd1, read_data2_out => rd2, read_addr1_in => ra1, read_addr2_in => ra2, reset => rst, clk => clk, write_addr_in => wa, write_data_in => wd, write_enable_in => we);
   
    process
    begin
      rst <= '1', '0' after 10ns;
      we <= '0';
      wa <= "00111";
      wd <= "00000000000000001010100010111101";
      clk <= '0', '1' after 5ns, '0' after 10ns, '1' after 15ns, '0' after 20ns, '1' after 25ns, '0' after 30ns, '1' after 35ns, '0' after 40ns, '1' after 45 ns, '0' after 50ns, '1' after 55ns, '0' after 60ns, '1' after 65ns, '0' after 70ns, '1' after 75ns, '0' after 80ns, '1' after 85ns, '0' after 90ns, '1' after 95 ns;
      
      -- Case 1
      ra1 <= "00000";
      ra2 <= "00101";
      wait for 10 ns;
      
     we <= '1', '0' after 30ns;
     
     -- Case 2
           
      ra1 <= "01111";
      ra2 <= "00111";
      wait for 10 ns;

    end process;
    
end Test_Arch;
