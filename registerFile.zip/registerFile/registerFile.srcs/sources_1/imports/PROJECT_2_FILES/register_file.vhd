library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;


entity register_file is
  port ( 
    reset : in std_logic;
    clk : in std_logic;
    write_enable_in : in std_logic;
    read_addr1_in : in std_logic_vector(4 downto 0); -- we use only 4 bits though here;
    read_addr2_in : in std_logic_vector(4 downto 0);
    write_addr_in : in std_logic_vector(4 downto 0);
    write_data_in : in std_logic_vector(31 downto 0);
    read_data1_out : out std_logic_vector(31 downto 0); 
    read_data2_out : out std_logic_vector(31 downto 0)
  );
end register_file;


architecture behavioral_arch of register_file is

	type REG_ARRAY_32x32 is array(0 to 31) of std_logic_vector(31 downto 0);

begin  
	
	data_mem_process: process (reset, clk, read_addr1_in, read_addr2_in, write_addr_in, write_data_in) is
		variable var_data_reg : REG_ARRAY_32x32;
		variable var_addr1 : integer;
		variable var_addr2 : integer;
		variable var_write_addr : integer;
	begin
		var_addr1 := conv_integer(read_addr1_in(4 downto 0));   
		var_addr2 := conv_integer(read_addr2_in(4 downto 0));
		var_write_addr := conv_integer(write_addr_in(4 downto 0));
		if (reset = '1') then
			-- desired initial values of the data memory:
			var_data_reg(0)  := X"00000000"; 
			var_data_reg(1)  := X"00000000";
			var_data_reg(2)  := X"00000000";
			var_data_reg(3)  := X"00000000";
			var_data_reg(4)  := X"00000000";
			var_data_reg(5)  := X"00000000";
			var_data_reg(6)  := X"00000000";
			var_data_reg(7)  := X"00000000";
			var_data_reg(8)  := X"00000000";
			var_data_reg(9)  := X"00000000";
			var_data_reg(10) := X"00000000";
			var_data_reg(11) := X"00000000";
			var_data_reg(12) := X"00000000";
			var_data_reg(13) := X"00000000";
			var_data_reg(14) := X"00000000";
			var_data_reg(15) := X"00000000";
			var_data_reg(16) := X"00000000";
			var_data_reg(17) := X"00000000";
			var_data_reg(18) := X"00000000";
			var_data_reg(19) := X"00000000";
			var_data_reg(20) := X"00000000";
			var_data_reg(21) := X"00000000";
			var_data_reg(22) := X"00000000";
			var_data_reg(23) := X"00000000";
			var_data_reg(24) := X"00000000";
			var_data_reg(25) := X"00000000";
			var_data_reg(26) := X"00000000";
			var_data_reg(27) := X"00000000";
			var_data_reg(28) := X"00000000";
			var_data_reg(29) := X"00000000";
			var_data_reg(30) := X"00000000";
			var_data_reg(31) := X"00000000";
		elsif (rising_edge(clk) and write_enable_in = '1') then
			-- synchronous write data in on rising edge of clock
			var_data_reg(var_write_addr) := write_data_in;
		end if;
	 
		-- asynchronous continuous read of the data memory location at address var_addr 
		read_data1_out <= var_data_reg(var_addr1);
		read_data2_out <= var_data_reg(var_addr2);
		
	end process;
  
end behavioral_arch;
