library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity data_memory is
  port ( 
    reset, clk, write_enable : in std_logic;
    ReadReg1, ReadReg2, WriteReg : in std_logic_vector(4 downto 0);
    WriteData : in std_logic_vector(31 downto 0);
    ReadData1, ReadData2 : out std_logic_vector(31 downto 0)    
  );
end data_memory;

architecture behavioral_arch of data_memory is
    type MEM_ARRAY is array(0 to 31) of std_logic_vector(31 downto 0);
begin  
    process (clk, reset) is
        variable mem : MEM_ARRAY;
    begin
        if (reset = '1') then
            mem := (others => (others => '0'));
            mem(10) := X"00000001"; -- Setup initial values
            mem(11) := X"00000002";
            mem(13) := X"00000003";
        elsif (rising_edge(clk) and write_enable = '1') then
            mem(conv_integer(WriteReg)) := WriteData;  
        end if;
        ReadData1 <= mem(conv_integer(ReadReg1));
        ReadData2 <= mem(conv_integer(ReadReg2));
    end process;
end behavioral_arch;