
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity instruction_memory is 
    port ( 
        addr_in   : in  std_logic_vector(31 downto 0); 
        instr_out : out std_logic_vector(31 downto 0) 
    );
end instruction_memory;

architecture behavioral_arch of instruction_memory is

begin	    
	
    instr_mem_process: process (addr_in) is
        variable var_addr : integer;
    begin 
        -- Shift right by 2 
        -- This maps byte addresses (0, 4, 8) to word indices (0, 1, 2)
        var_addr := conv_integer(addr_in(5 downto 2));

        case var_addr is
           
            when 0  => instr_out <= x"00A02303";  --  LW t1, 10(x0) 
            when 1  => instr_out <= x"00B02383";   --  LW t2, 11(x0) 
            when 2  => instr_out <= x"00D02E03";     --  LW t3, 13(x0)
            when 3  => instr_out <= x"00730EB3"; -- 4. ADD t4, t1, t2
            when 4  => instr_out <= x"00730F33";    -- 5. ADD t5, t1, t2
            when 5  => instr_out <= x"01D38463";    -- 6. BEQ t3, t4, 2
            when 6  => instr_out <= x"01D38F33";   -- 7. ADD t5, t3, t4 
            when 7  => instr_out <= x"01E02723";    -- 8. SW t5, 14(x0) 
            when 8  => instr_out <= x"00E02F83"; -- 9. LW t6, 14(x0)
            when others =>  
                instr_out <= x"00000000";  -- Fills 32 bits with 0 
        end case;
    end process;
  
end behavioral_arch;