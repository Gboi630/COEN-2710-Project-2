----------------------------------------------------------------------------------
-- Company: Marquette University
-- Engineer: Giancarlo Ortega and Parker Alig
-- 
-- Module Name: data_path
-- Description:  wiring of datapath
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity data_path is
    Port(
        clk             : in  STD_LOGIC;
        reset           : in  STD_LOGIC;
        result          : out STD_LOGIC_VECTOR(31 downto 0);
        pc_out_probe    : out STD_LOGIC_VECTOR(31 downto 0);
        instr_out_probe : out STD_LOGIC_VECTOR(31 downto 0);
        rd1_probe       : out STD_LOGIC_VECTOR(31 downto 0);
        rd2_probe       : out STD_LOGIC_VECTOR(31 downto 0)
    );
end data_path;

architecture Behavioral of data_path is


-- Component declaration                               

component Main_Control is
    Port ( 
        Opcode: in std_logic_vector(6 downto 0);
        Branch, MemRead, MemtoReg, MemWrite, ALUSrc, RegWrite: out std_logic;
        ALUOp: out std_logic_vector(1 downto 0)
    );
end component;

component ALU_Control is
    Port ( 
        Funct7: in std_logic_vector(6 downto 0);
        Funct3: in std_logic_vector(2 downto 0);
        ALUOp: in std_logic_vector(1 downto 0);
        ALUOperation: out std_logic_vector(3 downto 0)
    );
end component;

component data_memory is
    Port ( 
        reset, clk, write_enable : in std_logic;
        ReadReg1, ReadReg2, WriteReg : in std_logic_vector(4 downto 0);
        WriteData : in std_logic_vector(31 downto 0);
        ReadData1, ReadData2 : out std_logic_vector(31 downto 0)    
    );
end component;

component instruction_memory is 
    Port ( 
        addr_in : in std_logic_vector(31 downto 0);
        instr_out : out std_logic_vector(31 downto 0) 
    );
end component;

component register_file is
    Port ( 
        reset, clk, write_enable_in : in std_logic;
        read_addr1_in, read_addr2_in, write_addr_in : in std_logic_vector(4 downto 0);
        write_data_in : in std_logic_vector(31 downto 0);
        read_data1_out, read_data2_out : out std_logic_vector(31 downto 0)
    );
end component;

component ALU_32bit is
    Port (
        a, b         : in  STD_LOGIC_VECTOR(31 downto 0);
        ALUOperation : in  STD_LOGIC_VECTOR(3 downto 0);
        CarryOut     : out STD_LOGIC;
        Result       : out STD_LOGIC_VECTOR(31 downto 0);
        Overflow     : out STD_LOGIC;
        Zero         : out STD_LOGIC
    );
end component;

component thirty_two_bit_adder is
    Port ( 
        a, b : in STD_LOGIC_VECTOR(31 downto 0);
        z    : out STD_LOGIC_VECTOR(31 downto 0);
        cout : out STD_LOGIC 
    );
end component;

component mux2to1 is
    Port ( 
        in0, in1 : in  STD_LOGIC_VECTOR(31 downto 0);
        sel      : in  STD_LOGIC;
        mux_out  : out STD_LOGIC_VECTOR(31 downto 0)
    );
end component;

component PC IS
    PORT ( 
        I : IN STD_LOGIC_VECTOR (31 DOWNTO 0);
        CLK, Reset, Set : IN STD_LOGIC;
        Q : OUT STD_LOGIC_VECTOR (31 DOWNTO 0)
    );
END component;

component ImmGen is
    Port ( 
        inst : in STD_LOGIC_VECTOR(31 downto 0);
        output : out STD_LOGIC_VECTOR(31 downto 0)
    );
end component;


--Signals needed                     


signal instr_out   : STD_LOGIC_VECTOR(31 downto 0);
signal pc_out      : STD_LOGIC_VECTOR(31 downto 0);
signal pc_in       : STD_LOGIC_VECTOR(31 downto 0);
signal pc_add_4    : STD_LOGIC_VECTOR(31 downto 0);
signal branchAdd   : STD_LOGIC_VECTOR(31 downto 0);
signal immgen_out  : STD_LOGIC_VECTOR(31 downto 0);
signal rd1, rd2    : STD_LOGIC_VECTOR(31 downto 0);
signal ALU_result  : STD_LOGIC_VECTOR(31 downto 0);
signal writeData   : STD_LOGIC_VECTOR(31 downto 0);
signal alu_mux_out : STD_LOGIC_VECTOR(31 downto 0);
signal dm_rd       : STD_LOGIC_VECTOR(31 downto 0);

signal ALUCont     : STD_LOGIC_VECTOR(3 downto 0);
signal ALUOp       : STD_LOGIC_VECTOR(1 downto 0);
signal branch, zero, regWrite, ALUSrc, memWrite, memtoReg, memRead : STD_LOGIC;
signal addMuxIn    : STD_LOGIC;

begin


--WIRING



-- AND gate for Branch decision of the MUX
addMuxIn <= branch AND zero;

--  Main Control ports
u1: Main_Control Port Map(
    Opcode   => instr_out(6 downto 0),
    Branch   => branch,
    MemRead  => memRead,
    MemtoReg => memtoReg,
    MemWrite => memWrite,
    ALUSrc   => ALUSrc,
    RegWrite => regWrite,
    ALUOp    => ALUOp
); 

--  ALU Control
u2: ALU_Control Port Map ( 
    Funct7       => instr_out(31 downto 25),
    Funct3       => instr_out(14 downto 12),
    ALUOp        => ALUOp,
    ALUOperation => ALUCont
);
    
-- Data Memory
u3: data_memory Port Map ( 
    reset        => reset,
    clk          => clk,
    write_enable => memWrite, 
    ReadReg1     => ALU_result(4 downto 0), -- 5-bit address
    ReadReg2     => (others => '0'),
    WriteReg     => ALU_result(4 downto 0),
    WriteData    => rd2,
    ReadData1    => dm_rd,
    ReadData2    => open
);

--  Instruction Memory
u4: instruction_memory Port Map( 
    addr_in   => pc_out,
    instr_out => instr_out
);
  
--  Register File
u5: register_file Port Map(
    reset           => reset,
    clk             => clk,
    write_enable_in => regWrite,
    read_addr1_in   => instr_out(19 downto 15),
    read_addr2_in   => instr_out(24 downto 20),
    write_addr_in   => instr_out(11 downto 7),
    write_data_in   => writeData,
    read_data1_out  => rd1,
    read_data2_out  => rd2
);

-- 32-bit Structural ALU
u6: ALU_32bit Port Map(
    a            => rd1,
    b            => alu_mux_out,
    ALUOperation => ALUCont,
    Result       => ALU_result,
    Zero         => zero,
    Overflow     => open,
    CarryOut     => open
);

-- U7: Branch Adder 
u7: thirty_two_bit_adder Port Map(
    a    => pc_out,
    b    => immgen_out,
    z    => branchAdd,
    cout => open
);

--  PC+4 Adder 
u8: thirty_two_bit_adder Port Map(
    a    => pc_out,
    b    => x"00000004",
    z    => pc_add_4,
    cout => open
);

-- U9: Data Memory Mux 
u9: mux2to1 Port Map(
    in0     => ALU_result,
    in1     => dm_rd,
    sel     => memtoReg,
    mux_out => writeData
);

-- U10: ALU Source Mux
u10: mux2to1 Port Map( 
    in0     => rd2,
    in1     => immgen_out,
    sel     => ALUSrc,
    mux_out => alu_mux_out
);
  
-- U11: PC Input Mux
u11: mux2to1 Port Map(
    in0     => pc_add_4,
    in1     => branchAdd,
    sel     => addMuxIn,
    mux_out => pc_in
);

-- U12: Program Counter
u12: PC Port Map(
    I     => pc_in,
    CLK   => clk,
    Reset => reset,
    Set   => '0',
    Q     => pc_out
);

-- U13: Immediate Generator
u13: ImmGen Port Map(
    inst   => instr_out,
    output => immgen_out
);

-- Assign Probes
result          <= ALU_result;
pc_out_probe    <= pc_out;
instr_out_probe <= instr_out;
rd1_probe       <= rd1;
rd2_probe       <= rd2;

end Behavioral;