----------------------------------------------------------------------------------
-- Company: Marquette University
-- Engineer: Giancarlo Ortega and Parker Alig
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_data_path is
end tb_data_path;

architecture sim of tb_data_path is
   