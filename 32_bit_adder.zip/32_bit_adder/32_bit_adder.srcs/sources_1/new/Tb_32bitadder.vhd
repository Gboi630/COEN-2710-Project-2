----------------------------------------------------------------------------------
-- Company: Marquette University
-- Engineer: Giancarlo Ortega & Parker Alig
-- 
-- Create Date: 03/31/2026 01:50:02 PM
-- Design Name: 32 bit adder
-- Module Name: Tb_32bitadder - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


-- 32-bit adder testbench
-- This testbench applies a few input cases to the adder
-- and checks whether the sum and carry-out match the expected results.

-- This is just to make a reference to some common things needed.

LIBRARY IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Declare a testbench. The testbench does not have any input or output ports. 
-- The testbench has no input or output ports because all signals are internal.
                          
entity TEST_32_Bit_Adder is
end TEST_32_Bit_Adder;

-- Describes the functionality of the tesbench.

architecture MY_TEST of TEST_32_Bit_Adder is 

	component thirty_two_hit_adder
		port( a, b	: in    STD_LOGIC_VECTOR(31 downto 0);
		      z		: out	STD_LOGIC_VECTOR(31 downto 0);
		      cout	: out 	STD_LOGIC);
	end component;

	for U1: thirty_two_hit_adder use entity WORK.thirty_two_bit_adder(MY_STRUCTURE);
	signal a, b	: STD_LOGIC_VECTOR(31 downto 0);
	signal z	: STD_LOGIC_VECTOR(31 downto 0);
	signal cout	: STD_LOGIC;
	
	begin
	U1: thirty_two_hit_adder port map (a,b,z,cout);
	
		process
		begin

		-- Case 1 that we are testing. We add two zeros to confirm simple functions. 

			a <= x"00000000";
			b <= x"00000000";
			wait for 10 ns;
			assert ( z = x"00000000" )	report "Failed Case 1 - z" severity error;
			assert ( Cout = '1' )   report "Failed Case 1 - Cout" severity error;
			wait for 40 ns;

		-- Case 2 that we are testing. Adding a small value to zero and check that the sum passes through correctly.

			a <= x"00000000";
			b <= x"0000000F";
			wait for 10 ns;
			assert ( z = x"0000000F" )	report "Failed Case 2 - z" severity error;
			assert ( Cout = '0' )   report "Failed Case 2 - Cout" severity error;
			wait for 40 ns;
			
		-- Case 3 that we are testing. Tested overflow
			 a <= x"F0000000";
             b <= x"F0000000";
             wait for 10 ns;
             assert ( z = x"E0000000" )    report "Failed Case 3 - z" severity error;
             assert ( Cout = '1' )   report "Failed Case 3 - Cout" severity error;
             wait for 40 ns;
		end process;
END MY_TEST;