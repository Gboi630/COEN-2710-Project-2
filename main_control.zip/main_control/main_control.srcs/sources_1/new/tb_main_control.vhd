

-- Testbench for checking the Main Control outputs for each required opcode case.

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Main_Control_tb is
end Main_Control_tb;

architecture Behavioral of Main_Control_tb is

    component Main_Control
        Port (
            Opcode   : in  STD_LOGIC_VECTOR(6 downto 0);
            Branch   : out STD_LOGIC;
            MemRead  : out STD_LOGIC;
            MemtoReg : out STD_LOGIC;
            MemWrite : out STD_LOGIC;
            ALUSrc   : out STD_LOGIC;
            RegWrite : out STD_LOGIC;
            ALUOp    : out STD_LOGIC_VECTOR(1 downto 0)
        );
    end component;

    signal Opcode   : STD_LOGIC_VECTOR(6 downto 0);
    signal Branch   : STD_LOGIC;
    signal MemRead  : STD_LOGIC;
    signal MemtoReg : STD_LOGIC;
    signal MemWrite : STD_LOGIC;
    signal ALUSrc   : STD_LOGIC;
    signal RegWrite : STD_LOGIC;
    signal ALUOp    : STD_LOGIC_VECTOR(1 downto 0);

begin

    -- Connect Main Control module
    MainControl_connect: Main_Control
        port map (
            Opcode   => Opcode,
            Branch   => Branch,
            MemRead  => MemRead,
            MemtoReg => MemtoReg,
            MemWrite => MemWrite,
            ALUSrc   => ALUSrc,
            RegWrite => RegWrite,
            ALUOp    => ALUOp
        );

    -- Apply test cases
    process
    begin
        -- R-type
        Opcode <= "0110011";
        wait for 10 ns;

        -- lw
        Opcode <= "0000011";
        wait for 10 ns;

        -- sw
        Opcode <= "0100011";
        wait for 10 ns;

        -- beq
        Opcode <= "1100011";
        wait for 10 ns;

        wait;
    end process;

end Behavioral;