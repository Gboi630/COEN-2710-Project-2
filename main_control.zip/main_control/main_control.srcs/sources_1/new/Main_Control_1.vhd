----------------------------------------------------------------------------------
-- Company: 
-- Engineer: Giancarlo Ortega
-- Create Date: 04/07/2026 12:36:43 AM
-- Design Name:  Main Control
-- Module Name: main_control - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

--Main control outputs by checking the opcode and assigning the matching signals.

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;




entity Main_Control is
--  Takes the 7 bit opcode and outputs the control signals 
  Port ( 
  Opcode: in std_logic_vector(6 downto 0);
  Branch,MemRead,MemtoReg,MemWrite,ALUSrc,RegWrite: out std_logic;
  ALUOp: out std_logic_vector(1 downto 0)
  );
end Main_Control;

architecture Behavioral of Main_Control is

begin
Main_Control_process: process (Opcode)
begin

--R-type
if Opcode = "0110011" then 
    Branch   <= '0';
    MemRead  <= '0';
    MemtoReg <= '0';
    MemWrite <= '0';
    ALUSrc   <= '0';
    RegWrite <= '1';
    ALUOp    <= "10";
end if;

--lw instruction
if Opcode = "0000011" then 
    Branch   <= '0';
    MemRead  <= '1';
    MemtoReg <= '1';
    MemWrite <= '0';
    ALUSrc   <= '1';
    RegWrite <= '1';
    ALUOp    <= "00";
end if;

--sw instruction
if Opcode = "0100011" then 
    Branch   <= '0';
    MemRead  <= '0';
    MemtoReg <= '0';
    MemWrite <= '1';
    ALUSrc   <= '1';
    RegWrite <= '0';
    ALUOp    <= "00";
end if;

--beq instruction
if Opcode = "1100011" then 
    Branch   <= '1';
    MemRead  <= '0';
    MemtoReg <= '0';
    MemWrite <= '0';
    ALUSrc   <= '0';
    RegWrite <= '0';
    ALUOp    <= "01";
end if;

    end process;
end Behavioral;