--Giancarlo Ortega and Parker Alig-- 

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity tb_data_path is
end tb_data_path;

architecture behavior of tb_data_path is

    component data_path
    Port (
        clk : in STD_LOGIC;
        reset : in STD_LOGIC;
        result : out STD_LOGIC_VECTOR(31 downto 0);
        pc_out_probe : out STD_LOGIC_VECTOR(31 downto 0);
        instr_out_probe : out STD_LOGIC_VECTOR(31 downto 0);
        rd1_probe : out STD_LOGIC_VECTOR(31 downto 0);
        rd2_probe : out STD_LOGIC_VECTOR(31 downto 0);
        writeData_probe : out STD_LOGIC_VECTOR(31 downto 0)
    );
end component;

    -- Signals
    signal clk_tb : STD_LOGIC := '0';
    signal reset_tb : STD_LOGIC := '1';

    signal result_tb : STD_LOGIC_VECTOR(31 downto 0);
    signal pc_out : STD_LOGIC_VECTOR(31 downto 0);
    signal instr_out : STD_LOGIC_VECTOR(31 downto 0);
    signal rd1_probe : STD_LOGIC_VECTOR(31 downto 0);
    signal rd2_probe : STD_LOGIC_VECTOR(31 downto 0);
    signal writeData_probe : STD_LOGIC_VECTOR(31 downto 0);

begin

    -- Instantiate DUT
    uut: data_path
        Port Map (
            clk => clk_tb,
            reset => reset_tb,
            result => result_tb,
            pc_out_probe => pc_out,
            instr_out_probe => instr_out,
            rd1_probe => rd1_probe,
            rd2_probe => rd2_probe,
            writeData_probe => writeData_probe
        );

    -- Clock Process
    clk_process : process
    begin
        while now < 300 ns loop   -- enough time to finish program
            clk_tb <= '0';
            wait for 5 ns;
            clk_tb <= '1';
            wait for 5 ns;
        end loop;
        wait;
    end process;

    -- Reset Process
    reset_process : process
    begin
        reset_tb <= '1';
        wait for 20 ns;   -- 2 clock cycles (10 ns each)
        reset_tb <= '0';
        wait;
    end process;

end behavior;