--Giancarlo Ortega and Parker Alig-- 

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Main_Control is
    Port ( 
        Opcode    : in  std_logic_vector(6 downto 0);
        Branch    : out std_logic;
        MemRead   : out std_logic;
        MemtoReg  : out std_logic;
        MemWrite  : out std_logic;
        ALUSrc    : out std_logic;
        RegWrite  : out std_logic;
        ALUOp     : out std_logic_vector(1 downto 0)
    );
end Main_Control;

architecture Behavioral of Main_Control is
begin

process(Opcode)
begin
    -- Default Values
    Branch    <= '0';
    MemRead   <= '0';
    MemtoReg  <= '0';
    MemWrite  <= '0';
    ALUSrc    <= '0';
    RegWrite  <= '0';
    ALUOp     <= "00";

    case Opcode is

        -- R-Type
        when "0110011" =>
            RegWrite <= '1';
            ALUSrc   <= '0';
            ALUOp    <= "10";

        -- Load
        when "0000011" =>
            RegWrite <= '1';
            MemRead  <= '1';
            MemtoReg <= '1';
            ALUSrc   <= '1';   
            ALUOp    <= "00";

        -- Store
        when "0100011" =>
            MemWrite <= '1';
            ALUSrc   <= '1';   
            ALUOp    <= "00";

        -- Branch
        when "1100011" =>
            Branch <= '1';
            ALUSrc <= '0';    
            ALUOp  <= "01";

        -- Invalid input
        when others =>
            -- keep safe defaults (do nothing)
            null;

    end case;

end process;

end Behavioral;