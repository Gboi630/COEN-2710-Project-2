
--Giancarlo Ortega and Parker Alig--

--MSB_ALU is used for overflow and set and has aluonebit functions--

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity MSB_ALU is
    Port (
        a            : in  STD_LOGIC;
        b            : in  STD_LOGIC;
        cin          : in  STD_LOGIC;
        ALUOperation : in  STD_LOGIC_VECTOR(3 downto 0);
        Result       : out STD_LOGIC;
        cout         : out STD_LOGIC;
        set          : out STD_LOGIC;
        overflow     : out STD_LOGIC
    );
end MSB_ALU;

architecture Behavioral of MSB_ALU is

    --  signal of b for Sub
    signal b_in : STD_LOGIC;

    -- Basic operation results signals
    signal and_result : STD_LOGIC;
    signal or_result  : STD_LOGIC;
    signal sum_result : STD_LOGIC;
    signal nor_result : STD_LOGIC;

    -- Carry + overflow 
    signal cout_int : STD_LOGIC;
    signal overflow_internal : STD_LOGIC;

begin

    -- Invert b for SUB and SLT
    b_in <= not b when (ALUOperation = "0110" or ALUOperation = "0111") else b;

    -- Logic operations
    and_result <= a and b;
    or_result  <= a or b;
    nor_result <= not (a or b);

    -- Adder logic
    sum_result <= a xor b_in xor cin;

    cout_int <= (a and b_in) or (cin and (a xor b_in));
    cout <= cout_int;

    -- Overflow detection
    overflow_internal <= cin xor cout_int;
    overflow <= overflow_internal;

    -- Set signal for SLT
    set <= sum_result xor overflow_internal;

    -- Final output selection
    with ALUOperation select
        Result <= and_result when "0000",
                  or_result  when "0001",
                  sum_result when "0010",
                  sum_result when "0110",
                  '0'        when "0111",
                  nor_result when "1100",
                  '0'        when others;

end Behavioral;