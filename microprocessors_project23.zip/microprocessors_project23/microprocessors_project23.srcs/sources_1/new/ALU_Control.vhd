----------------------------------------------------------------------------------
-- Company: 
-- Engineer: Parker Alig & Gian Ortega
-- 
-- Create Date: 04/07/2026 11:21:54 PM
-- Design Name: 
-- Module Name: ALU_Control - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ALU_Control is
  Port ( 
        Funct7: in std_logic_vector(6 downto 0);
        Funct3: in std_logic_vector(2 downto 0);
        ALUOp: in std_logic_vector(1 downto 0);
        ALUOperation: out std_logic_vector(3 downto 0)
  );
end ALU_Control;

architecture Behavioral of ALU_Control is
begin

process(ALUOp, Funct7, Funct3)
begin
    case ALUOp is
        when "00" => ALUOperation <= "0010"; -- ADD
        when "01" => ALUOperation <= "0110"; -- SUB

        when "10" =>
            if Funct3 = "000" and Funct7 = "0000000" then
                ALUOperation <= "0010"; -- ADD
            elsif Funct3 = "000" and Funct7 = "0100000" then
                ALUOperation <= "0110"; -- SUB
            elsif Funct3 = "111" then
                ALUOperation <= "0000"; -- AND
            elsif Funct3 = "110" then
                ALUOperation <= "0001"; -- OR
            else
                ALUOperation <= "0010";
            end if;

        when others =>
            ALUOperation <= "0010";
    end case;
end process;

end Behavioral;
