

--Giancarlo Ortega and Parker Alig-- 

--ALU1BIT handles operations for every single bit seperately 
-- a, b, cin, cout, result bit--

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


--add all entities

entity ALU1BIT is
    Port (
        a            : in  STD_LOGIC;
        b            : in  STD_LOGIC;
        less         : in  STD_LOGIC;
        cin          : in  STD_LOGIC;
        ALUOperation : in  STD_LOGIC_VECTOR(3 downto 0);
        Result       : out STD_LOGIC;
        cout         : out STD_LOGIC
    );
end ALU1BIT;

architecture Behavioral of ALU1BIT is

    -- signal of b.
    -- For subtraction and SLT, b is inverted.
    signal b_in : STD_LOGIC;

    -- These are the results from this 1-bit slice.
    signal and_result : STD_LOGIC;
    signal or_result  : STD_LOGIC;
    signal sum_result : STD_LOGIC;
    signal nor_result : STD_LOGIC;

begin

    -- For SUB and SLT used the inverse b.
    b_in <= not b when (ALUOperation = "0110" or ALUOperation = "0111") else b;

    -- Basic logic 
    and_result <= a and b;
    or_result  <= a or b;
    nor_result <= not (a or b);

    -- Sum bit 
    sum_result <= a xor b_in xor cin;

    -- Carry out equation.
    cout <= (a and b_in) or (cin and (a xor b_in));

    -- Pick the final result based on the ALU control input.
    with ALUOperation select
        Result <= and_result when "0000", -- AND
                  or_result  when "0001", -- OR
                  sum_result when "0010", -- ADD
                  sum_result when "0110", -- SUB
                  less       when "0111", -- SLT
                  nor_result when "1100", -- NOR
                  '0'        when others;

end Behavioral;