--Giancarlo Ortega and Parker Alig-- 

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity register_file is
  port ( 
    reset : in std_logic;
    clk : in std_logic;
    write_enable_in : in std_logic;
    read_addr1_in : in std_logic_vector(4 downto 0);
    read_addr2_in : in std_logic_vector(4 downto 0);
    write_addr_in : in std_logic_vector(4 downto 0);
    write_data_in : in std_logic_vector(31 downto 0);
    read_data1_out : out std_logic_vector(31 downto 0); 
    read_data2_out : out std_logic_vector(31 downto 0)
  );
end register_file;

architecture behavioral_arch of register_file is

    -- ? Persistent storage (THIS is the key fix)
    type REG_ARRAY_32x32 is array(0 to 31) of std_logic_vector(31 downto 0);
    signal data_reg : REG_ARRAY_32x32 := (others => (others => '0'));

begin

    -- Write process
    process(clk, reset)
    begin
        if reset = '1' then
            data_reg <= (others => (others => '0'));

        elsif rising_edge(clk) then
            if write_enable_in = '1' then
                data_reg(to_integer(unsigned(write_addr_in))) <= write_data_in;
            end if;
        end if;
    end process;

    -- Read
    read_data1_out <= data_reg(to_integer(unsigned(read_addr1_in)));
    read_data2_out <= data_reg(to_integer(unsigned(read_addr2_in)));

end behavioral_arch;