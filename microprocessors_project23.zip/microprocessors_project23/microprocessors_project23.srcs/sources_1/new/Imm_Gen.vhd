----------------------------------------------------------------------------------
-- Company: Marquette University 
-- Engineer: Giancarlo Ortega & Parker Alig
-- 
-- Project Name: Project 2 Part 3
-- Description: Immediate Generator
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ImmGen is
    Port ( 
        inst : in STD_LOGIC_VECTOR(31 downto 0);
        output : out STD_LOGIC_VECTOR(31 downto 0)
    );
end ImmGen;

architecture Behavioral of ImmGen is

begin

process(inst)
begin
    case inst(6 downto 0) is
        -- R-type 
            when "0110011" => 
            output <= (others => '0');

        -- I-type
        when "0000011" => 
            output(11 downto 0)  <= inst(31 downto 20);
            output(31 downto 12) <= (others => inst(31)); -- Sign extension 

        -- S-type 
        when "0100011" =>
            output(11 downto 5)  <= inst(31 downto 25);
            output(4 downto 0)   <= inst(11 downto 7);
            output(31 downto 12) <= (others => inst(31)); -- Sign extension 

        -- B-type 
        when "1100011" =>
            output(0)            <= '0'; -- Implicit 0 for half-word alignment
            output(4 downto 1)   <= inst(11 downto 8);
            output(10 downto 5)  <= inst(30 downto 25);
            output(11)           <= inst(7);
            output(12)           <= inst(31);
            output(31 downto 13) <= (others => inst(31)); -- Sign extension 

        when others => 
            output <= (others => '0');
    end case;
end process;

end Behavioral;