
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity mux2to1 is
    Port ( 
        in0     : in  STD_LOGIC_VECTOR(31 downto 0); -- 32-bit Input 0
        in1     : in  STD_LOGIC_VECTOR(31 downto 0); -- 32-bit Input 1
        sel     : in  STD_LOGIC;                     -- Select signal
        mux_out : out STD_LOGIC_VECTOR(31 downto 0)  -- 32-bit Output
    );
end mux2to1;

architecture Dataflow of mux2to1 is
begin
    -- Simple dataflow assignment for the multiplexer logic
    mux_out <= in0 when (sel = '0') else in1;
end Dataflow;