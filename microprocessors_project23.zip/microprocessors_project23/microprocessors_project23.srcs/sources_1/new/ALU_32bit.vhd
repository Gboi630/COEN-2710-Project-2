--Giancarlo Ortega and Parker Alig--
--top level and connects the 32 bits w/ carry and assigns final output--

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


--list all components
entity ALU_32bit is
    Port (
        a            : in  STD_LOGIC_VECTOR(31 downto 0);
        b            : in  STD_LOGIC_VECTOR(31 downto 0);
        ALUOperation : in  STD_LOGIC_VECTOR(3 downto 0);
        CarryOut     : out STD_LOGIC;
        Result       : out STD_LOGIC_VECTOR(31 downto 0);
        Overflow     : out STD_LOGIC;
        Zero         : out STD_LOGIC
    );
end ALU_32bit;

architecture Structural of ALU_32bit is


-- Add all the lower level code along with its components
    component ALU1BIT
        Port (
            a            : in  STD_LOGIC;
            b            : in  STD_LOGIC;
            less         : in  STD_LOGIC;
            cin          : in  STD_LOGIC;
            ALUOperation : in  STD_LOGIC_VECTOR(3 downto 0);
            Result       : out STD_LOGIC;
            cout         : out STD_LOGIC
        );
    end component;

    component MSB_ALU
        Port (
            a            : in  STD_LOGIC;
            b            : in  STD_LOGIC;
            cin          : in  STD_LOGIC;
            ALUOperation : in  STD_LOGIC_VECTOR(3 downto 0);
            Result       : out STD_LOGIC;
            cout         : out STD_LOGIC;
            set          : out STD_LOGIC;
            overflow     : out STD_LOGIC
        );
    end component;

    -- Carry values between each ALU slice
    signal carry : STD_LOGIC_VECTOR(31 downto 0);

    -- Internal results for all 32 bits
    signal result_int : STD_LOGIC_VECTOR(31 downto 0);

    -- Set signal from MSB back to bit 0 for SLT
    signal set_sig : STD_LOGIC;

begin

    -- For SUB and SLT, start with carry-in = 1
    carry(0) <= '1' when (ALUOperation = "0110" or ALUOperation = "0111") else '0';

    -- Least significant bit
    bit0: ALU1BIT
        port map (
            a            => a(0),
            b            => b(0),
            less         => set_sig,
            cin          => carry(0),
            ALUOperation => ALUOperation,
            Result       => result_int(0),
            cout         => carry(1)
        );

    -- Middle bits
    gen_middle: for i in 1 to 30 generate
        bit_i: ALU1BIT
            port map (
                a            => a(i),
                b            => b(i),
                less         => '0',
                cin          => carry(i),
                ALUOperation => ALUOperation,
                Result       => result_int(i),
                cout         => carry(i + 1)
            );
    end generate;

    -- Most significant bit
    bit31: MSB_ALU
        port map (
            a            => a(31),
            b            => b(31),
            cin          => carry(31),
            ALUOperation => ALUOperation,
            Result       => result_int(31),
            cout         => CarryOut,
            set          => set_sig,
            overflow     => Overflow
        );

    -- Final outputs
    Result <= result_int;
    Zero <= '1' when result_int = x"00000000" else '0';

end Structural;