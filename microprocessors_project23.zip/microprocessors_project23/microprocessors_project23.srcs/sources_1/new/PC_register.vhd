----------------------------------------------------------------------------------
-- Company: Marquette University
-- Engineer: Giancarlo Ortega and Parker Alig

----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

ENTITY PC IS 
  PORT ( 
    I               : IN  STD_LOGIC_VECTOR (31 DOWNTO 0); -- Next PC address
    CLK             : IN  STD_LOGIC;                      -- System Clock
    Reset           : IN  STD_LOGIC;                      -- Asynch Reset to 0
    Set             : IN  STD_LOGIC;                      -- Asynch Set to all 1s
    Q               : OUT STD_LOGIC_VECTOR (31 DOWNTO 0)  -- Current PC address
  );
END PC;

ARCHITECTURE my_functional_descr OF PC IS

BEGIN
    PROCESS (Set, Reset, CLK)
    BEGIN    
        -- Asynchronous Set takes highest priority
        IF Set = '1' THEN
            Q <= (OTHERS => '1');
            
        -- Asynchronous Reset takes second priority
        ELSIF Reset = '1' THEN
            Q <= (OTHERS => '0');
            
        -- Update the PC address on the rising edge of the clock
        ELSIF (CLK'EVENT AND CLK = '1') THEN
            Q <= I;
        END IF;
    END PROCESS;
  
END my_functional_descr;