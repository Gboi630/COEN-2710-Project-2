library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity data_memory is
  port ( 
    reset, clk, write_enable : in std_logic;
    ReadReg1, ReadReg2, WriteReg : in std_logic_vector(4 downto 0);
    WriteData : in std_logic_vector(31 downto 0);
    ReadData1, ReadData2 : out std_logic_vector(31 downto 0)    
  );
end data_memory;

architecture behavioral_arch of data_memory is

    type MEM_ARRAY is array(0 to 31) of std_logic_vector(31 downto 0);

    signal mem : MEM_ARRAY := (
        10 => X"00000001",
        11 => X"00000002",
        13 => X"00000003",
        others => X"00000000"
    );

begin

    -- Write/reset process
    process(clk, reset)
    begin
        -- Reset
        if reset = '1' then
            mem <= (
                10 => X"00000001",
                11 => X"00000002",
                13 => X"00000003",
                others => X"00000000"
            );

        -- Write
        elsif rising_edge(clk) then
            if write_enable = '1' then
                mem(to_integer(unsigned(WriteReg))) <= WriteData;
            end if;
        end if;
    end process;

    -- Asynchronous read
    ReadData1 <= mem(to_integer(unsigned(ReadReg1)));
    ReadData2 <= mem(to_integer(unsigned(ReadReg2)));

end behavioral_arch;