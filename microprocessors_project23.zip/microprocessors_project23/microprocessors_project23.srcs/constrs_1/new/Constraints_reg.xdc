# cristinel.ababei@marquette.edu


###############################################################################
# PART 1: read and use this if you are required to use an FPGA board like 
# BASYS 3 to do this project. Otherwise, jump to PART 2.
#
# NOTE: Any line that starts with # is a comment 
#
# This is an example of Constraints used for the fourbit_adder
# design entity - implemented and verified on Basys 3 board (xc7a35tcpg236-1 chip)!
# When you create a new Constraints file in your Vivado project,
# the file is created in folder local to the project's folder, like this:
# {Path to Vivado Projects Folder}\fourbit_adder\fourbit_adder.srcs\constrs_1\new\fourbit_adder_constraints.xdc
#
# The (.xdc) constraints file specifies what input/output pins of the
# top-level design entity connect to pins of the FPGA chip.
# You need such constraints to be able to test the design on
# the Basys 3 board and to get accurate Timing Reports (after
# Synthesis and after Implementation steps inside the Vivado Project)


# This is a simple example of how to set constraints for the fourbit_adder
# design entity connected to pins of the FPGA chip that are  wired on the 
# Basys 3 board to slide switches and LEDs, which will be used for testing operation.



###############################################################################  
# PART 2: read and use this if you are required to do simulations only,
# but, you still need to do "timing analysis" to find the "timing most critical
# path delay" in yoru synthesized circuits!
# 
# If you want to do advanced configuration of Vivado tool and force it
# to do some timing optimization of your design entity, then, you
# can specifically set some timing constraints to be met by the
# final implemented circuit. 


# Part <a> 
# Combinational circuits, like the fourbit_adder
#
# In any pure combinatorial design, the path-to-path constraint is used to 
# describe the delay the circuit can tolerate. 

set_max_delay -datapath_only -from [all_inputs] -to [all_outputs] 9.500

# NOTES A:
#
# 1) The above constraint can also be written like this:
#set_max_delay -from [get_ports {{a[0]} {a[1]} {a[2]} {a[3]} {b[0]} {b[1]} {b[2]} {b[3]}}] -to [get_ports {cout {z[0]} {z[1]} {z[2]} {z[3]}}] 9.500
#
# 2) Another way one can set timing constraints is to create a 
# virtual clock of a desired rather small clock period:
#create_clock -period 9.500 -name virtual_clock
#set_input_delay -clock [get_clocks virtual_clock] -max -add_delay 0.000 [get_ports {a[0]}]
#set_output_delay -clock [get_clocks virtual_clock] -max -add_delay 0.000 [get_ports cout]



# Part <b> 
# Sequential circuits, timing constraints are a bit more complex. 
#
# In sequential circuits, period, input delay, and output delay constraints are used.
# An example would like like this:

create_clock -name clk -period 50.000 [get_ports clk]
set_input_delay -clock clk -max 3.0 [all_inputs]
set_input_delay -clock clk -min 1.0 [all_inputs]
set_output_delay -clock clk 2.0 [all_outputs]
set_max_delay -datapath_only -from [all_inputs] -to [all_outputs] 50.000


# NOTES 2:
# 
# 1) For design entities with many inputs and outputs, you may get an ERROR during Synthesis and Implementation
# steps like this:
# "[Place 30-415] IO Placement failed due to overutilization. This design contains ??? I/O ports..."
# That happens when the design entity has more pins than the selected target chip.
# Usually this sort of error comes from trying to synthesize a piece of logic that will 
# ultimately be only a part of a larger design. An example is your Registers Components.
# In those cases every top level IO port would normally just be another net within the fabric,
# later on when you will assemble the whole processor, and ??? of them is not unreasonable in a newer part. 
# You might be able to synthesize if you uncheck the option to "Add I/O Buffers," but obviously 
# the result of that synthesis would not be something you could load into hardware by itself.
# To get around this error do the following:
# - Right-click on Run Synthesis in the Vivado tool:
# - Scroll down the Options
# - In the "More Options" field, type: -mode out_of_context, in order for the tool not to infer any I/O buffers!
# - Click Apply
# 
# 2) You can read more details on the above in Section 2 of the following lab7 from Xilinx:
# https://www.xilinx.com/support/documentation/university/Vivado-Teaching/HDL-Design/2015x/VHDL/docs-pdf/lab7.pdf
# Also, you can type "create_clock -help" in the Tcl Console at the bottom side of the Vivado tool in your project.

